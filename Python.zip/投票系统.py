﻿#模块
import time 
import os,sys

#time
lct = time.asctime()

#投票年龄最小限制
LVA = '15'
LVA2 = '80'
LVA3 = '100'
#选项
A = '共产党'
B = '普京'
C = 'ISIS恐怖分子'
D = '傻逼才投，老子就不投'
#神经病回答
testX1 = 'D'
testX2 = 'C'
abcd =  '100'
name = input('请在此输入你的名字：')
print ('亲爱的',name,'感谢你使用本系统进行投票')
age = input('请输入你的年龄:')

if age >= LVA :
    print ('你的年龄已经达到限定的最小年龄，请在下方选择你支持的人/党/组织')
    print ('A =',A,' ','B =',B,' ','C =',C,'D =',D)
    ticket = input('请在此输入:')
    
    if ticket == testX1 : 
        print ('你小子给我等着，我记下了')
    else :
        print ('你投的是',ticket)
        print ('感谢你参与投票')
        print ('投票时间:',lct)

    if ticket == testX2 :
        print ('你多少有点反人类了')

if age >= LVA2 :
    print('老当益壮啊')
if age >= LVA3 :
    print('\033[1;31;4m 太老了，系统觉得你没有判断能力，所以不给你投了 \033[0m') 
    sys.exit(0)
    
    

else :
    print ('你的年龄太小，还不能投票喔')


