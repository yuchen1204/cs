password = ('xiaohy1204')
wip = ('wrong password/username,please try again')

name = input('input your name:')
psswd = input('input you password:')

if psswd == password:
    print ('Hello',name)
else :
    print (wip)